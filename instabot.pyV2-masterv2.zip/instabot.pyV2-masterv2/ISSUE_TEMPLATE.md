Fill all requirements before sending issues. Or all issues will be closed without reading. 

- [ ] Did read [FAQ](https://github.com/ugurozturk/instabot.pyV2/wiki/FAQ)
- [ ] Searched and checked orher issues about my problem
- [ ] I have errors.log file and i did upload it

Check One :
- [ ] Bug
- [ ] Feature
- [ ] Need Help

## What OS ?
## Python Version ?
## Is it VPS ?
### VPS: Is the vps far far away ? Another Country ?
- [ ] VPS: Tried the same code via my local pc

## What is your python knowledge vote 0/10
